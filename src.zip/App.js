import Footer from './components/footer/Footer';
import Header from './components/Header/Header';

import { BrowserRouter as Router, Route, Switch } from "react-router-dom";


function Article(){
  return <article>
    <div>본문 들어갈 자리</div>
    <div>본문 들어갈 자리</div>
    <div>본문 들어갈 자리</div>
  </article>
 }


function App() {
  return (
    
    <div>
    <Header></Header>
    <Article></Article>
    <Article></Article>
    <Article></Article>
    <Article></Article>
    <Article></Article>
    <Article></Article>
    <Article></Article>
    <Article></Article>
    <Article></Article>
    <Article></Article>
    <Article></Article>
    <Article></Article>
    <Footer></Footer>
    </div>
  );
}

export default App;
