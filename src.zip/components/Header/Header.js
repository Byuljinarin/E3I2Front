import React from "react";
import styles from './Header.module.css';
import { KAKAO_AUTH_URL } from "../OAuth/Auth";

let code = new URL(window.location.href).searchParams.get("code");

function Header(){
    return <div>
        <div className={styles.HeaderSection}>
        <div className={styles.HeaderTitle}>PIYONG
          <div>
            <section><span className={styles.FooterMiddleTitle1}></span>
              <p className={styles.FooterMiddle}></p>
              <p className={styles.FooterMiddle2}></p>
              <p className={styles.FooterMiddle2}></p>
              <a href={KAKAO_AUTH_URL}><img src="/img/kakao_login_medium_narrow.png"></img></a>
            </section>
          </div>
          <div>{code}</div>
        </div>
        </div>
    </div>
}

export default Header;